public class Orders {
    Orders(Restuarants restuarants , Food food1 , User user1){condition=true;restuarant=restuarants;food=food1;user=user1;}
    public boolean condition ; // active = true , ...
    public Restuarants restuarant;
    public Food food;
    public User user;

}
