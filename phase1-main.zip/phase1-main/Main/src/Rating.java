public enum Rating {
    AWESOME,GOOD,NOTBAD,BAD,TERRIBLE
}
